<h2>Referências Bibliográficas</h2>
<ul>
    <li>MOREIRA, M. A. <i>Práticas de ensino eficazes: uma abordagem cognitiva</i>. Porto Alegre: Artes Médicas, 2017.</li>
    <li>STUDY.COM. Lethe: overview, mythology & facts. Study.com. Disponível em: <a href="https://study.com/academy/lesson/lethe-overview-mythology-facts.html">https://study.com/academy/lesson/lethe-overview-mythology-facts.html</a>. Acesso em: 19 set. 2024.</li>
    <li>PINTEREST. [Logo Instagram]. Pinterest. Disponível em: <a href="https://br.pinterest.com/pin/378372806211515895/">https://br.pinterest.com/pin/378372806211515895/</a>. Acesso em: 20 set. 2024.</li>
    <li>PINTEREST. [Marketing digital]. Pinterest. Disponível em: <a href="https://br.pinterest.com/pin/378372806211515895/">https://br.pinterest.com/pin/378372806211515895/</a>. Acesso em: 20 set. 2024.</li>
    <li>PINTEREST. [Flashcards]. Pinterest. Disponível em: <a href="https://br.pinterest.com/pin/378372806211515895/">https://br.pinterest.com/pin/378372806211515895/</a>. Acesso em: 20 set. 2024.</li>
    <li>PEÑALOZA, Rodrigo. Lethe: o rio do esquecimento. Medium. Disponível em: <a href="https://milesmithrae.medium.com/lethe-o-rio-do-esquecimento-rodrigo-pe%C3%B1alozajan-2015-6d2d8c837224">https://milesmithrae.medium.com/lethe-o-rio-do-esquecimento-rodrigo-pe%C3%B1alozajan-2015-6d2d8c837224</a>. Acesso em: 21 set. 2024.</li>
</ul>
